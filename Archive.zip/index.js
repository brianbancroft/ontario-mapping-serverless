const pg = require('pg');

exports.handler = function(event, context) {
  console.log('PostgreSQL GET Function');
  const conn = 'postgres://brianbancroft:G6IDNv7K@ontarioelections.cmfdjvezumip.us-east-1.rds.amazonaws.com/ontarioelection';

  const client = new pg.Client(conn);

  client.connect();

  console.log('Connected to PostgreSQL database');

  var queryString = `
    SELECT count(*) FROM census_lda;
  `
  var query = client.query(queryString);

  query.on('row', function (row, result) {
    result.addRow(row);
  });

  query.on('end', function (result) {
    var jsonString = JSON.stringify(result.rows);
    var jsonObj = JSON.parse(jsonString);
    console.log(jsonString);
    client.end();
    context.succeed(jsonObj);
  });
};
